package com.romina.waterbnb;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WaterbnbApplicationTests {

	@Test
	void contextLoads() {
	}

}
